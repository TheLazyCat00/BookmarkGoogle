the source code is already included (script/main.js)

1. go to root dir
2. run `npm install -g terser`
3. run `terser script/main.js -c -m -o script/minified.js`
